# RiceFlaskApp
Rice seed prediction 
